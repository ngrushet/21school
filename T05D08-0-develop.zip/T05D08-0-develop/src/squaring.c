#include <stdio.h>
#define NMAX 10

void input(int *a, int *n);
void output(int *a, int *n);
void squaring(int *a, int *n);
int get_decimal(int ptr);

int main() {
    int n, data[NMAX];
    input(data, &n);
    squaring(data, &n);
    output(data, &n);

    return 0;
}

void input(int *a, int *n) {
    if (!get_decimal(*n)) {
        printf("n/a");
        return;
    }
    printf("debug here, n = %d", *n);
    for (int *p = a; p - a < *n; p++) {
        printf("\nfor scanf\n");
        if (!get_decimal(*p)) {
            printf("n/a");
            return;
        }
    }
}

int get_decimal(int ptr){
    float temp;
    
    if (!scanf("%f", &temp)) {  // проверка на ввод числа
        printf("not a number");
        return 0;
    }
    
    if (temp != (int)(temp)) {  // проверка на целое
        printf("not a decimal");
        return 0;
    }
    else {
        ptr = (int)temp;
        printf("ptr is %d", ptr);
        return 1;
    }
}

void output(int *a, int *n) {
    for (int *p = a; p - a < *n; p++) {
        printf("%d ", *p);
    }
}

void squaring(int *a, int *n) {
    for (int *p = a; p - a < *n; p++) {
        
        *p = *p * (*p);
    }
}


