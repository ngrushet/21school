#ifndef SRC_LIST_H_
#define SRC_LIST_H_

struct Node {
    int degree;
    int coef;
    struct Node * next;
} Node;

void push(struct Node **head, int degree, int coef);
#endif  // SRC_LIST_H_

