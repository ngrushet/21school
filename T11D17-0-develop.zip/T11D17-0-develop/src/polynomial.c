#include <stdio.h>
#include <stdlib.h>
#include "./list.h"

char * input();
void search();

int main() {
    struct Node * head = NULL;
    char * string = input();

    recognition(string, head);


}

char * input() {
    char * string, buff;
    int i = 0;
    while(((buff = getchar()) != '.') && (buff!=13)) {
        string[i] = buff;
        i++;
    }
    string[i] = '\0';
    return string;
}

void recognition(char * string, struct Node ** head) {
    char buff;
    int i = 0, a = 0, d = 0;
    while (string[i] != '\0') {
        if (string[i] == 'x') {
            if ('0' <= string[i] && string[i] <= '9') {
                a = strtol(string[i], )
            }

            if (string[i+1] == ('+'||'-')) {
                push(*head, )
            }
        }
}
