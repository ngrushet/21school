#include <stdio.h>
#include "./list.h"

void push(struct Node **head, int degree, int coef) {
    struct Node *tmp = (struct Node *)malloc (sizeof(struct Node));
    tmp->coef = coef;
    tmp->degree = degree;
    tmp->next = (*head);
    (*head) = tmp;
}
