#include "./stack.h"

void init(int value) {
    struct Node *head = (struct Node *)malloc (sizeof(struct Node));
    head->value = value;
    head->next = NULL;
}

void push(struct Node **head, int value) {
    struct Node *tmp = (struct Node *)malloc (sizeof(struct Node));
    tmp->value = value;
    tmp->next = (*head);
    (*head) = tmp;
    free(tmp);
}

int pop(struct Node **head) {
    if (head->next != NULL) {
        struct Node * tmp = * head;  // берем адрес head, 
        free(head);             // сам хэд очищаем
        (* head) = tmp->next;   // хэд теперь следующий элемент
        free(tmp);              // стираем tmp
        printf("%d", head->value);
    } else {
        printf("Stack is empty!\n");
    }
}

void destroy(struct Node **head) {
    while (head->next != NULL) {
        pop(head);
    }
    printf("Stack is destroyed!\n");
}