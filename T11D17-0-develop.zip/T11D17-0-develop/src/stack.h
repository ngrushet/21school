#ifndef SRC_STACK_H_
#define SRC_STACK_H_

struct Node {
    int value;
    struct Node * next;
};

void init(int value);

void push(struct Node **head, int value);

int pop(struct Node **head);

void destroy(struct Node **head);
#endif  // SRC_STACK_H_