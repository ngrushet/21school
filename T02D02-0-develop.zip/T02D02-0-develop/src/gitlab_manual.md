# 1. Создание личного репозитория
## с нужным .gitignore и простым README.MD

Для создания нового репозитория используется команда git init. Команду git init выполняют только один раз для первоначальной настройки нового репозитория. Выполнение команды приведет к созданию нового подкаталога .git в вашем рабочем каталоге. Кроме того, будет создана новая главная ветка.
	git init 

# 2. Создание веток develop и master
 
Чтобы создать новую ветку master, следует написать в терминале следующее:

    git checkout -b master

Чтобы создать ветку develop, достаточно ввести то же самое, только заменить слово master на develop

# 3. Установка ветки develop по умолчанию.

Чтобы изменить ветвь по умолчанию в GitLab:
1. Настройки > Общие > Общие настройки проекта > Развернуть
2. Ветвь по умолчанию > Измените ветвь проекта по умолчанию
3. Сохраните изменения

![Картинка](sourse/picture.png)

Подробнее можно прочитать здесь: <https://coderoad.ru/30987216/%D0%98%D0%B7%D0%BC%D0%B5%D0%BD%D0%B8%D1%82%D1%8C-%D0%B2%D0%B5%D1%82%D0%B2%D1%8C-%D0%BF%D0%BE-%D1%83%D0%BC%D0%BE%D0%BB%D1%87%D0%B0%D0%BD%D0%B8%D1%8E-%D0%B2-gitlab>

# 4. Cоздание issue на создание текущего мануала.

Тебе проще посмотреть это видео: <https://www.youtube.com/watch?v=uKJbEH7Y7mM>

# 5. Создание ветки по issue

###Create a new issue
When you create a new issue, you are prompted to fill in the data and fields of the issue, as illustrated below. If you know the values you want to assign to an issue, you can use the Quick actions feature to input values.

While creating an issue, you can associate it to an existing epic from current group by selecting it using Epic dropdown.

###Accessing the New Issue form
There are many ways to get to the New Issue form from a project’s page:

* Navigate to your Project’s Dashboard > Issues > New Issue:

![ещё картинка](source/new_issue_from_tracker_list.png)
 
* From an open issue in your project, click the vertical ellipsis () button to open a dropdown menu, and then click New Issue to create a new issue in the same project:

![Third pic](source/new_issue_from_open_issue_v13_6.png)

* From your Project’s Dashboard, click the plus sign (+) to open a dropdown menu with a few options. Select New Issue to create an issue in that project:

![pic4](source/new_issue_from_projects_dashboard.png) 

* From an Issue Board, create a new issue by clicking on the plus sign (+) at the top of a list. It opens a new issue for that project, pre-labeled with its respective list.

![pic5](source/new_issue_from_issue_board.png)

Подробнее здесь: <https://docs.gitlab.com/ee/user/project/issues/managing_issues.html#create-a-new-issue>

# 6. Создание merge request по ветке в develop.

##Merge request tabs
Merge requests contain tabs at the top of the page to help you navigate to important parts of the merge request:
![pic](source/merge_request_tab_position_v13_11.png)

Merge request tab positions

* Overview: Contains the description, notifications from pipelines, and a discussion area for comment threads) and code suggestions. The right sidebar provides fields to add assignees, reviewers, labels, and a milestone to your work, and the merge request widgets area reports results from pipelines and tests.
* Commits: Contains a list of commits added to this merge request. For more information, read Commits tab in merge requests.
* Pipelines: If configured, contains a list of recent GitLab CI/CD pipelines and their status.
* Changes: Contains the diffs of files changed by this merge request. You can configure the display.

# 7. Комментирование и принятие request.

When commenting on a diff, you can select which lines of code your comment refers to by either:

![pic](source/comment-on-any-diff-line_v13_10.png)

other: <https://docs.gitlab.com/ee/user/project/merge_requests/reviews/#comment-on-multiple-lines>

# 8. Формирование стабильной версии в master с простановкой тега.
###Stable version
A stable CI/CD template is a template that only introduces breaking changes in major release milestones. Name the stable version of a template as <template-name>.gitlab-ci.yml, for example Jobs/Deploy.gitlab-ci.yml.

You can make a new stable template by copying the latest template available in a major milestone release of GitLab like 13.0. All breaking changes must be announced in a blog post before the official release, for example GitLab.com is moving to 13.0, with narrow breaking changes

You can change a stable template version in a minor GitLab release like 13.1 if:

* The change is not a breaking change.
* The change is ported to the latest template, if one exists.

More: <https://docs.gitlab.com/ee/development/cicd/templates.html#stable-version>

# 9. Работа с wiki проекта.

###Wiki
If you don’t want to keep your documentation in your repository, but you want to keep it in the same project as your code, you can use the wiki GitLab provides in each GitLab project. Every wiki is a separate Git repository, so you can create wiki pages in the web interface, or locally using Git.

Also the link: <https://docs.gitlab.com/ee/user/project/wiki/#wiki>

