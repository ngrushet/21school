#!/bin/sh

echo "Lets Analize files.log file!"

read where
if [ ! -f "$where" ]; then
    echo "File not existing, run command again."
    exit
fi

if [ ! $(basename $where) = 'files.log' ]; then
    echo "maybe it's not files.log file?) Run command again"
    exit
fi

# количество строк в логе
lines=$(wc $where | awk '{print $1}')

# количество уникальных файлов
uniq=$(cat $where | awk '{print $1}' | uniq | wc | awk '{print $1}')

# количество уникальных хэшей
uniqhashs=$(cat $where | awk -F ' - ' '{print $4}' | uniq | wc | awk '{print $1}' )

printf "$lines $uniq $uniqhashs\n"
