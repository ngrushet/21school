#!/bin/sh

echo "Lets edit!"

read where
if [ ! -f "$where" ]; then
	echo "File not existing, run command again."
	exit
fi

read what
if [ -z "$what" ]; then
	echo "empty string 1 typed error, run command again"
	exit
fi

read change
if [ -z "$change" ]; then
	echo "empty string 2 typed error, run command again"
	exit
fi

sed -i '' "s/$what/$change/g" $where
log_path='files.log'
date1=$( date +"%F %H:%M")
hash=$( shasum -a 256 $where | awk '{print $1}')
size=$( stat -f%z $where)
algo='sha256'
echo "$(basename "$PWD")/$where - $size - $date1 - $hash - $algo" >> $log_path 
