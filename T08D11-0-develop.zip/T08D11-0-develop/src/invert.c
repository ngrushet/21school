// Copyright [year] <Copyright Owner>
//
// Created by Tashia Buttercup on 22.07.2021.
//

#include <stdio.h>
#include <stdlib.h>

void input_size(int *n_size_row, int *n_size_col, int *flag);
void pointer_allocated(double **pointer_el, double *matrix_num, int n_size_row, int n_size_col);
void input_num(double **pointer_el, int n_size_row, int n_size_col, int *flag);
void output_matrix(double **matrix_num, int n_size_row, int n_size_col);

double determine(double **matrix, int n_size_row, int n_size_col);
double **minor(double **matrix, int n_size_row, int n_size_col, int row, int col);

int main() {
    int n_size_row, n_size_col, flag;
    input_size(&n_size_row, &n_size_col, &flag);
    if (flag == 0) {
        double *matrix = (double *) malloc(n_size_col * n_size_row * sizeof(double ));
        double **pointer_el = (double **) malloc(n_size_col * sizeof(double *));

        pointer_allocated(pointer_el, matrix, n_size_row, n_size_col);
        input_num(pointer_el, n_size_row, n_size_col, &flag);

        output_matrix(pointer_el, n_size_row, n_size_col);
        printf("\n\n");
        if (n_size_col == n_size_row) {
//            double dete = 0;
        output_matrix(minor(pointer_el, n_size_row, n_size_col, 1, 1), n_size_row - 1, n_size_col - 1);
//            dete = determine(pointer_el, n_size_row, n_size_col);
//            printf("%.6f", dete);
        } else {
            printf("n/a");
        }


        free(matrix);
        free(pointer_el);

    } else {
        printf("n/a");
    }
}

void input_size(int *n_size_row, int *n_size_col, int *flag) {
    *flag = 0;
    char c;
    char c1;
    if (scanf("%d%c%d%c", n_size_row, &c, n_size_col, &c1) ==
        4 && c == 32 && c1 == 10 && *n_size_row > 0 && *n_size_col > 0) {
    } else {
        *flag = 1;
    }
}

void input_num(double **pointer_el, int n_size_row, int n_size_col, int *flag) {
    double p_str;
    char c_srt;
    for (int i = 0; i < n_size_row; i++) {
        for (int j = 0; j < n_size_col; j++) {
            if (scanf("%lf%c", &p_str, &c_srt) == 2 && (c_srt == 32 || c_srt == 10)) {
                pointer_el[i][j] = p_str;
            } else {
                *flag = 1;
            }
        }
    }
}

void output_matrix(double **matrix_num, int n_size_row, int n_size_col) {
    for (int j = 0; j < n_size_row; j++) {
        for (int i = 0; i < n_size_col; i++) {
            if (i + 1 != n_size_col) {
                printf("%.6f ", matrix_num[j][i]);
            } else {
                printf("%.6f", matrix_num[j][i]);
            }
        }
        if (j + 1!= n_size_row) {
            printf("\n");
        }
    }
}

void pointer_allocated(double **pointer_el, double *matrix_num, int n_size_row, int n_size_col) {
    for (int i = 0; i < n_size_row; i++) {
        pointer_el[i] = matrix_num + i * n_size_col;
    }
    for (int i = 0; i < n_size_row; i++) {
        for (int j = 0; j < n_size_col; j++) {
            pointer_el[i][j] = 66;
        }
    }
}
double determine(double **matrix, int n_size_row, int n_size_col) {
    double det = matrix[0][0];
    if (n_size_row > 1 && n_size_col > 1) {
        det = 0;
        for (int i = 0; i < n_size_col; i++) {
            double **mino = minor(matrix, n_size_row, n_size_col, i, 0);
            if (i % 2 == 0) {
                det += (matrix[i][0]) * (determine(mino, n_size_row - 1, n_size_col - 1));
            } else {
                det -= (matrix[i][0]) * (determine(mino, n_size_row - 1, n_size_col - 1));
            }
            free(mino);
        }

    } else {
        return det;
    }
    return det;
}

// test
// 1 2 3 4 5 6 7 8 9
// 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16
// 4 4
// 1 -2 3 8
// 4 0 6 5
// -7 8 9 19
// 4 6 1 6

double **minor(double **matrix, int n_size_row, int n_size_col, int row, int col) {
    double *matrix_minor = (double *) malloc((n_size_col - 1) * (n_size_row - 1) * sizeof(double ));
    double **pointer_el_minor = (double **) malloc((n_size_col - 1) * sizeof(double *));

    pointer_allocated(pointer_el_minor, matrix_minor, n_size_row - 1, n_size_col - 1);
    if (row !=0 && col != 0) {
        for (int i = 0; i < n_size_row - 1; i++) {
            for (int j = 0; j < n_size_col - 1; j++) {
                if (i != row) {
                    if (j != col) {
                        pointer_el_minor[i][j] = matrix[i][j];
                    } else {
                        pointer_el_minor[i][j] = matrix[i][j+1];
                    }

                } else {
                    if (j != col) {
                        pointer_el_minor[i][j] = matrix[i+1][j];
                    } else {
                        pointer_el_minor[i][j] = matrix[i + 1][j + 1];
                    }
                }
            }
        }
    } else {
        for (int i = 0; i < n_size_row; i++) {
            for (int j = 0; j < n_size_col; j++) {
                if (i != row && j != 0) {
                    pointer_el_minor[i - 1][j - 1] = matrix[i][j];
                }
            }
        }
    }

    return  pointer_el_minor;
}

double **algebraic_complements(double **matrix, int n_size_row, int n_size_col, row, col) {
    double **minorr = minor(matrix, n_size_row, n_size_col, row, col);
}


