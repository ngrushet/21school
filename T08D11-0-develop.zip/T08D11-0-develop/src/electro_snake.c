// Copyright [year] <Copyright Owner>
//
// Created by Tashia Buttercup on 22.07.2021.
//

#include <stdio.h>
#include <stdlib.h>
/*
    1 6 7
    2 5 8
    3 4 9
*/


/*
    1 2 3
    6 5 4
    7 8 9
*/
void sort_horizontal(int **matrix, int n, int m, int **result_matrix);

/*
    7 8 9
    6 1 2
    5 4 3
*/
void input_size(int *n_size_row, int *n_size_col, int *flag);
void pointer_allocated(int **pointer_el, int *matrix_num, int n_size_row, int n_size_col);
void input_num(int **pointer_el, int n_size_row, int n_size_col, int *flag);

void output_matrix(int **matrix_num, int n_size_row, int n_size_col);
void output_matrix_vectoraze(int *matrix_vectoraze, int n_size_row, int n_size_col);
void sort_vertical(int **matrix_old, int *matrix_vectoraze, int **matrix_new, int n_size_row, int n_size_col);
void sort_spiral(int **matrix_old, int *matrix_vectoraze, int **matrix_new, int n_size_row, int n_size_col);

int  main() {
    int n_size_row, n_size_col, flag, mode;
    input_size(&n_size_row, &n_size_col, &flag);
    if (flag == 0) {
        int* matrix = (int *) malloc(n_size_col * n_size_row * sizeof(int));
        int* matrix_vectoraze = (int *) malloc(n_size_col * n_size_row * sizeof(int));
        int* *pointer_el = (int **) malloc(n_size_row * sizeof(int*));

        pointer_allocated(pointer_el, matrix, n_size_row, n_size_col);
        input_num(pointer_el, n_size_row, n_size_col, &flag);

        int* matrix_sort = (int *) malloc(n_size_col * n_size_row * sizeof(int));
        int* *pointer_el_sort = (int **) malloc(n_size_row * sizeof(int*));
        pointer_allocated(pointer_el_sort, matrix_sort, n_size_col, n_size_row);


        if (flag == 0) {
            output_matrix(pointer_el, n_size_row, n_size_col);

            sort_vertical(pointer_el, matrix_vectoraze, pointer_el_sort, n_size_row, n_size_col);
            printf("\n______________________\n");
            output_matrix_vectoraze(matrix_vectoraze, n_size_row, n_size_col);
            printf("\n______________________\n");
            output_matrix(pointer_el_sort, n_size_row, n_size_col);

            free(matrix);
            free(matrix_vectoraze);
            free(pointer_el);
            free(matrix_sort);
            free(pointer_el_sort);
        } else {
            printf("n/a");
        }

    } else {
        printf("n/a");
    }

    return  0;
}

void input_size(int *n_size_row, int *n_size_col, int *flag) {
    *flag = 0;
    char c;
    char c1;
    if (scanf("%d%c%d%c", n_size_row, &c, n_size_col, &c1) ==
        4 && c == 32 && c1 == 10 && *n_size_row > 0 && *n_size_col > 0) {
    } else {
        *flag = 1;
    }
}

void input_num(int **pointer_el, int n_size_row, int n_size_col, int *flag) {
    int p_str;
    char c_srt;
    for (int i = 0; i < n_size_row; i++) {
        for (int j = 0; j < n_size_col; j++) {
            if (scanf("%d%c", &p_str, &c_srt) ==
                2 && (c_srt == 32 || c_srt == 10)) {
                pointer_el[i][j] = p_str;
            } else {
                *flag = 1;
            }
        }
    }
}

void output_matrix(int **matrix_num, int n_size_row, int n_size_col) {
    for (int j = 0; j < n_size_row; j++) {
        for (int i = 0; i < n_size_col; i++) {
            if (i + 1 != n_size_col) {
                printf("%d ", matrix_num[j][i]);
            } else {
                printf("%d", matrix_num[j][i]);
            }
        }
        if (j + 1!= n_size_row) {
            printf("\n");
        }
    }
}

void output_matrix_vectoraze(int *matrix_vectoraze, int n_size_row, int n_size_col) {
    for (int i = 0; i < n_size_row * n_size_col; i++) {
            if (i + 1 != n_size_col * n_size_row) {
                printf("%d ", matrix_vectoraze[i]);
            } else {
                printf("%d", matrix_vectoraze[i]);
            }
        }
}

void pointer_allocated(int **pointer_el, int *matrix_num, int n_size_row, int n_size_col) {
    for (int i = 0; i < n_size_row; i++) {
        pointer_el[i] = matrix_num + i * n_size_col;
    }
    for (int i = 0; i < n_size_row; i++) {
        for (int j = 0; j < n_size_col; j++) {
            pointer_el[i][j] = 66;
        }
    }
}
// test
// 1 2 3 4 5 6 7 8 9
// 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15 16

void sort_vertical(int **matrix_old, int *matrix_vectoraze,
                   int **matrix_new, int n_size_row, int n_size_col) {
    int count = 0;
    for (int i = 0; i < n_size_row; i++) {
        for (int j = 0; j < n_size_col; j++) {
                matrix_vectoraze[count] = matrix_old[i][j];
                count++;
        }
    }
    count = 0;

//    int matrix_vectoraze_1[n_size_col * n_size_row];

    for (int i = 0; i < n_size_row * n_size_col; i++) {
        matrix_vectoraze_1[i] = matrix_vectoraze[i];
    }
