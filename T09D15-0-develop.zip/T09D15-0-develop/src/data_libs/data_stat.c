#include "data_stat.h"

double max(double *data, int n) {
    double max = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] > max) {
            max = data[i];
        }
    }
    return max;
}
double min(double *data, int n) {
    double min = data[0];
    for (int i = 1; i < n; i++) {
        if (data[i] < min) {
            min = data[i];
        }
    }
    return min;
}

double mean(double *data, int n) {
    double mean = 0;
    for (int i = 0; i < n; i++) {
        mean += data[i];
    }
    return mean/n;
}

double variance(double *data, int n) {
    double variance = 0;
    double sum_1 = 0, sum_2 = 0;
    for (int i = 0; i < n; i++) {
        sum_1 += data[i]*data[i];
        sum_2 += data[i];
    }
    return variance = sum_1 - sum_2*sum_2;
}
