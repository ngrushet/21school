#include <stdio.h>

int main() {
    char name[] = {0};
    scanf("%s", name);
    printf("Hello, %s!", name);
    return 0;
}
