#include <stdio.h>

int sum(int a, int b);

int diff(int a, int b);

int mult(int a, int b);

int divv(int a, int b);

int main() {
    
    float a, b;

    scanf("%f %f", &a, &b);

    if ( ( (int)a != a) || ( (int)b != b) ) { // проверка на целое
        printf("n/a");
        return 0;
    }

    printf("%d %d %d ", sum(a,b), diff(a,b), mult(a,b));
    divv(a,b);

    return 0;
}

int sum(int a, int b) {
    return (a + b);
}

int diff(int a, int b) {
    return (a - b);
}

int mult(int a, int b) {
    return (a * b);
}

int divv(int a, int b) {
    if (b==0) printf("n/a");
    else printf("%d", (a / b));
    return;
}