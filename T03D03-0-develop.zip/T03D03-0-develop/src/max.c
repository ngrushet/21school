#include <stdio.h>

int max(int a, int b);

int main() {

    float a, b;

    if (!scanf("%f %f", &a, &b)) { // проверка на число

        printf("n/a");
        return 0;
    }


    if ( ( (int)a != a) || ( (int)b != b) ) { // проверка на целое
        printf("n/a");
        return 0;
    }

    printf("%d", max(a,b));

    return 0;



}

int max(int a, int b) {
    if (a>=b) return a;
    else return b;
}