#include <stdio.h>
#include <math.h>

int main() {
    float x;

    if (scanf("%f", &x)) { // проверка на число

        float y = 7*powf(10, -3) * powf(x, 4) + ((22.8 * powf(x, (1 / 3)) - 1 * powf(10, 3) * x + 3) / (x * x / 2) - x * powf((10 + x), (2/x)) - 1.01);
        printf("%f", y);

    }
    else {
        printf("n/a");

        return 0;
    }
    return 0;  
}