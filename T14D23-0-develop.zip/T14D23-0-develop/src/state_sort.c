#include <stdio.h>
#include <stdlib.h>

void sort();
void add();

int menu_input();
void print_log();

struct log {
    int year;
    int month;
    int day;
    int hour;
    int min;
    int sec;
    int status;
    int code;
};

int main() {
    // void (*func[3])(void) = {print_log, sort, add};  

    int choice = menu_input();
    printf("\nmenu chosen");
    if (choice == 1) {
        printf("\n%d", choice);
        print_log();
    }

    // (func[choice])();
    return 0;
}

int menu_input() {
    printf("\nMenu input:");
    int choice1;
    scanf("%d", &choice1);
    return choice1;
}

void print_log() {
    printf("\nprint started;\n");
    FILE * file;
    file = fopen("../datasets/door_state_1", "rb");
    
    // посивольный перевод из файла в stdout
    char buf;// = getc(file);
    fread(&buf, sizeof(char), 1, file);


    //
    
    while ((buf != EOF)) {
        
        fputc(buf, stdout);
        // buf = getc(file);
        fread(&buf, sizeof(char), 1, file);
    }
    fclose(file);
}

void sort() {
    printf("in process ");
}

void add() {
    printf("in process add ");
}