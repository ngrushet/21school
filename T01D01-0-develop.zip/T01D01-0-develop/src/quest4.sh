pkill -f ai_door_control.sh
