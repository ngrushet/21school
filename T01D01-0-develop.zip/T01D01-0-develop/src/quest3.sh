#!/bin/bash
mv door_managment_fi door_managment_files

cd door_managment_files
mkdir door_configuration
mkdir door_map
mkdir door_logs
echo 'Успешно!'


echo 'сортируем файлы по папкам:'

ls

mv *.conf door_configuration
mv *.log door_logs
mv door_map_1.1 door_map

echo 'Готово'
