#!/bin/bash

touch main.key
cd ai_help

cd key
rm file*
