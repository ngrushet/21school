#include <stdio.h>

int fibo(int n);

int main() {
    float n;

    if (!scanf("%f", &n)) {  // проверка на число
        printf("n/a");
        return 0;
    } else {
        if ((int)n != n)  {  // проверка на целое
            printf("n/a");
            return 0;
        }


        if (n < 0) {  // проверка на неотрицательность
            printf("n/a");
        return 0;
        }

        printf("%d", fibo(n - 1));
        return 0;
    }
}

int fibo(int n) {  // рекурсивная функция
    if (n == 0 || n == 1) return 1;  // первые 2 числа равны 1
    return fibo(n - 1) + fibo(n - 2);  // складываем предыдущие 2 числа
}
