#include <stdio.h>
#include <time.h>
#include <string.h>

#include "print_module.h"

char print_char(char ch) {
    return putchar(ch);
}

void hms(char * buf) {
    const struct tm * ltime = time(NULL);
    strftime(buf, sizeof(buf), "%HH:%MM:%SS", ltime);
}


void print_log(char (* print) (char), char * message) {
    // печатаем префикс
    char buff[7] = Log_prefix;
    int i = 0;
    while (buff[i]!='\0') {
        (* print)(buff[i]);
        i++;
    }
    (*print)(' ');
    // печатаем время


    // печатаем месседж
    i = 0;
    while (message[i] != '\0') {
        (* print)(message[i]);
        i++;
    } 
}