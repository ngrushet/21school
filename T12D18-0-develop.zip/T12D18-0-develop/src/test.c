#include <stdio.h>  //Для printf
#include <time.h>   //Для time, localtime_r, asctime_r

int main (void)
{    
   //Переменная для сохранения текущего системного времени
   long int s_time;
   //Структура, в который будет помещен результат преобразования
   struct tm m_time;
   //Буфер, в который будет записана текстовая строка
   char buf[26]="";

   //Считываем текущее системное время
   s_time = time (NULL);

   //Преобразуем системное время в локальное
   localtime_r (&s_time, &m_time);

   // С помощью функции asctime_r преобразуем локальное время в строку
   // и выводим результат на консоль
   printf (“Время: %s\n”,asctime_r (&m_time,buf) );

   return 0;
}