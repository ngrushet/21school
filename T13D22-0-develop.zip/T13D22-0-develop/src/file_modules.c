#include <stdio.h>

#include "file_modules.h"

int cat() {
    // printf("\ncat go\n");
    FILE * f;
    char path[256];
    if (!scanf("%s", path)) {
        return 0;
    }
    if ((f = fopen(path, "r+")) == NULL) {
        // printf("\nfile not opened from cat");
        return 0;
    }
    // ("\nfile opened from cat");
    scan_n_put(f, stdout);
    return 1;
}

int putline() {
    printf("comming soon");
    FILE * f;
    char path[256];
    if (!scanf("%s", path)) {
        return 0;
    }
    if ((f = fopen(path, "r+")) == NULL) {
        // printf("\nfile not opened from cat");
        return 0;
    }
    scan_n_put(stdin, f);
}

int Cezar() {
    printf("comming soon");
}

int DES() {
    printf("comming soon");
}

int scan_n_put(FILE * from, FILE * to) {
    char buf;

    if ((buf = fgetc(from)) == EOF)   // Empty checking
        return 0;
    else
        fputc(buf, to);

    while ((buf = fgetc(from)) != EOF) {
        fputc(buf, to);
    }
    return 1;
}
