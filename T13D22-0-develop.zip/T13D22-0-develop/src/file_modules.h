#ifndef SRC_FILE_MODULES_H_
#define SRC_FILE_MODULES_H_

#define MAX_CHOICE 4
#define MIN_CHOICE 1

int load_file(FILE * file, const char * mode);

int scan_n_put(FILE * from, FILE * to);

int cat();

int putline();

int Cezar();

int DES();

#endif  // SRC_FILE_MODULES_H_
