#include <stdio.h>

#include "file_modules.h"

int menu_choice(int choice);
int out_of_menu_range(int choice);


int main() {
    int choice = 0;
    while (choice != -1) {
        if (!(scanf("%d", &choice))) {
            printf("n/a");
            return 0;
        }

        if (choice == -1)
            return 0;
        if (menu_choice(choice) == 0) {
            printf("n/a");
        }

        printf("\n");
    }
    return 0;
}

int menu_choice(int choice) {
    // printf("menu : ");
    // int (*functions[4])() = {cat, putline, Cezar, DES};
    if (out_of_menu_range(choice))
        return 0;

    if (choice == 1) {
        if (!(cat()))
            return 0;
    }
    return 1;
}

int out_of_menu_range(int choice) {
    if (((choice < MIN_CHOICE) || (MAX_CHOICE > choice)) && (choice != -1))
        return 0;
    return 1;
}
